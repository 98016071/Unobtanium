#pragma config(Sensor, S3,     HTIRL,               sensorI2CCustom)

byte irport=1;
#define mforward 7
#define mbackward 10
#define mstop 0

#include "hitechnic-irlink.h"

// Run the motors using the Single Pin Output Mode
void doPFsinglePinOutputModeTest(byte speed) {
  //nxtDisplayCenteredTextLine(1, "PFMotor %d", speed);
	switch (irport) {
	case 1:
  PFMotor(pfmotor_S3_C1_A, (ePWMMotorCommand)speed);
	PFMotor(pfmotor_S3_C1_B, (ePWMMotorCommand)speed);
	break;
	case 2:
  PFMotor(pfmotor_S3_C2_A, (ePWMMotorCommand)speed);
	PFMotor(pfmotor_S3_C2_B, (ePWMMotorCommand)speed);
	break;
 }
}

// Stop the motors
void stopMotors() {
  PFcomboDirectMode(HTIRL, irport-1, CDM_MOTOR_BRAKE, CDM_MOTOR_BRAKE);
}

task buttons() // Stop control
{
  while(true)
  {
    if(nNxtButtonPressed==0)
    {
      stopMotors();
      StopAllTasks();
    }
    wait1Msec(10);
  }
}

/*
  =============================================================================
  main task with some testing code

 */
task main
{
  nNxtExitClicks=2;
  StartTask(buttons);
  while (true) {
    doPFsinglePinOutputModeTest(mforward);	// forward
    wait1Msec(1000);
    doPFsinglePinOutputModeTest(mstop);	//stop
    wait1Msec(1000);
    doPFsinglePinOutputModeTest(mbackward);	//backward
    wait1Msec(1000);
   }
}
