
task main()
{
	while (true)
	{
motor[motorA]=100;
motor[motorB]=100;
motor[motorC]=100;
}


}
